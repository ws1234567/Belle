require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;

// 创建上传目录
const uploadDir = path.join(__dirname, 'public/uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// 配置文件上传
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

// 中间件
app.use(cors());
app.use(express.json());

// 处理错误的URL（全角括号问题）
app.get(/^\/admin[\uff09)]?$/i, (req, res) => {
    res.redirect('/admin.html');
});

app.use(express.static('public'));

// 数据库连接池
let pool;

// ========== 初始化数据库 ==========
async function initDatabase() {
    try {
        pool = await mysql.createPool({
            host: process.env.DB_HOST,
            port: parseInt(process.env.DB_PORT) || 3306,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME,
            waitForConnections: true,
            connectionLimit: 10,
            charset: 'utf8mb4'
        });
        
        console.log('✅ 数据库连接成功');
        
        // 创建作品表
        await pool.execute(`
            CREATE TABLE IF NOT EXISTS works (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(200) NOT NULL,
                category VARCHAR(50) NOT NULL,
                icon VARCHAR(100) DEFAULT 'fas fa-star',
                short_desc TEXT,
                full_desc TEXT,
                image_url VARCHAR(500),
                sort_order INT DEFAULT 0,
                user_id INT NULL,
                status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
                reject_reason TEXT,
                submitted_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `);

        // 创建普通用户表
        await pool.execute(`
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                avatar_url VARCHAR(500),
                email VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        // 创建管理员表
        await pool.execute(`
            CREATE TABLE IF NOT EXISTS admins (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // 创建注册码表（修改为支持管理员和用户注册码）
        await pool.execute(`
            CREATE TABLE IF NOT EXISTS register_codes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                code VARCHAR(50) UNIQUE NOT NULL,
                code_type ENUM('admin', 'user') DEFAULT 'user',
                is_used BOOLEAN DEFAULT FALSE,
                used_by VARCHAR(50),
                used_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // 创建轮播图表
        await pool.execute(`
            CREATE TABLE IF NOT EXISTS carousel_images (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(200),
                image_url VARCHAR(500) NOT NULL,
                link_url VARCHAR(500),
                sort_order INT DEFAULT 0,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `);

        // 创建网站设置表
        await pool.execute(`
            CREATE TABLE IF NOT EXISTS site_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                setting_key VARCHAR(100) UNIQUE NOT NULL,
                setting_value TEXT,
                description VARCHAR(200),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `);
        
        // 为works表添加新字段（如果不存在）
        try {
            await pool.execute(`ALTER TABLE works ADD COLUMN user_id INT NULL`);
        } catch (e) { if (!e.message.includes('Duplicate column')) throw e; }
        try {
            await pool.execute(`ALTER TABLE works ADD COLUMN status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending'`);
        } catch (e) { if (!e.message.includes('Duplicate column')) throw e; }
        try {
            await pool.execute(`ALTER TABLE works ADD COLUMN reject_reason TEXT`);
        } catch (e) { if (!e.message.includes('Duplicate column')) throw e; }
        try {
            await pool.execute(`ALTER TABLE works ADD COLUMN submitted_at TIMESTAMP NULL`);
        } catch (e) { if (!e.message.includes('Duplicate column')) throw e; }
        
        // 为register_codes表添加code_type字段（如果不存在）
        try {
            await pool.execute(`ALTER TABLE register_codes ADD COLUMN code_type ENUM('admin', 'user') DEFAULT 'user'`);
        } catch (e) { if (!e.message.includes('Duplicate column')) throw e; }
        
        // 检查并插入默认网站设置
        const [siteRows] = await pool.execute('SELECT * FROM site_settings');
        
        const checkAndInsert = async (key, value, description) => {
            const [rows] = await pool.execute('SELECT * FROM site_settings WHERE setting_key = ?', [key]);
            if (rows.length === 0) {
                await pool.execute('INSERT INTO site_settings (setting_key, setting_value, description) VALUES (?, ?, ?)', [key, value, description]);
            }
        };
        
        await checkAndInsert('site_title', 'ART•MASTER', '网站标题（显示在页面顶部）');
        await checkAndInsert('page_title', 'ART•MASTER', '浏览器标签页标题');
        await checkAndInsert('logo_icon', '', 'Logo图片URL');
        
        if (siteRows.length === 0) {
            console.log('📝 默认网站设置已创建');
        }
        
        // 检查并插入默认注册码（只有知道这个码的人才能注册）
        const [codeRows] = await pool.execute('SELECT * FROM register_codes WHERE code = ?', ['PORTFOLIO2025']);
        if (codeRows.length === 0) {
            await pool.execute('INSERT INTO register_codes (code) VALUES (?)', ['PORTFOLIO2025']);
            console.log('🔑 默认注册码已创建: PORTFOLIO2025');
        }
        
        // 检查并创建默认管理员（如果没有任何管理员，才创建）
        const [adminRows] = await pool.execute('SELECT * FROM admins');
        if (adminRows.length === 0) {
            const hash = await bcrypt.hash('admin123', 10);
            await pool.execute('INSERT INTO admins (username, password_hash) VALUES (?, ?)', ['admin', hash]);
            console.log('📝 默认管理员已创建: admin / admin123');
        }
        
        // 插入示例作品（如果表为空）
        const [workRows] = await pool.execute('SELECT COUNT(*) as count FROM works');
        if (workRows[0].count === 0) {
            const sampleWorks = [
                ['星云·动态身份系统', 'ui', 'fas fa-cloud-moon', '未来感仪表盘设计，动态数据可视化', '荣获2024 A设计奖，为AI公司设计的全场景认证系统，用户留存提升38%', null, 1],
                ['Ethereal 概念官网', 'web', 'fas fa-globe', '沉浸式3D滚动体验 + WebGL特效', 'Three.js打造超现实品牌官网，滚动粒子飞溅与摄像机视角变化', null, 2],
                ['霓虹制燥·品牌升级', 'brand', 'fas fa-brush', '潮牌全案视觉设计，动效LOGO与主视觉', '为街头品牌重塑视觉体系，社交媒体曝光20w+', null, 3],
                ['智能家居控制中枢', 'ui', 'fas fa-microchip', '多模态交互界面，支持语音/手势可视化', '红点设计概念奖，用户测试满意度94%', null, 4],
                ['虚实之间数字艺术展', 'web', 'fas fa-cube', '沉浸式线上展厅，Web3交互画廊', '线上3D空间月访问量破10万', null, 5],
                ['幻音音乐品牌重塑', 'brand', 'fas fa-head-side-vr', '动态视觉识别系统，融合声波美学', '品牌认知度提升150%', null, 6]
            ];
            for (const work of sampleWorks) {
                await pool.execute(
                    'INSERT INTO works (title, category, icon, short_desc, full_desc, image_url, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    work
                );
            }
            console.log('🎨 示例作品已添加');
        }
        
        console.log('📦 数据表初始化完成');
        
    } catch (err) {
        console.error('❌ 数据库初始化失败:', err.message);
        console.error('请检查: 1. MySQL服务是否启动 2. 数据库名是否已创建 3. 密码是否正确');
        process.exit(1);
    }
}

// ========== 验证Token中间件 ==========
function verifyToken(req, res, next) {
    const auth = req.headers.authorization;
    if (!auth) {
        return res.status(401).json({ success: false, error: '请先登录' });
    }
    const token = auth.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        return res.status(401).json({ success: false, error: '登录已过期，请重新登录' });
    }
}

// ========== API 路由 ==========

// 获取所有作品（公开 - 只显示审核通过的）
app.get('/api/works', async (req, res) => {
    try {
        const [rows] = await pool.execute(
            "SELECT id, title, category, icon, short_desc as `desc`, full_desc, image_url, sort_order FROM works WHERE status = 'approved' OR status IS NULL OR status = '' ORDER BY sort_order ASC, id DESC"
        );
        const categoryMap = { ui: 'UI/UX', web: 'Web 创意', brand: '品牌视觉' };
        const data = rows.map(row => ({
            ...row,
            categoryName: categoryMap[row.category] || row.category
        }));
        res.json({ success: true, data });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 获取单个作品
app.get('/api/works/:id', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM works WHERE id = ?', [req.params.id]);
        if (rows.length === 0) {
            return res.status(404).json({ success: false, error: '作品不存在' });
        }
        res.json({ success: true, data: rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 上传图片（需要登录）
app.post('/api/upload', verifyToken, upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, error: '请选择图片' });
    }
    const imageUrl = `/uploads/${req.file.filename}`;
    res.json({ success: true, imageUrl });
});

// 创建作品（需要登录）
app.post('/api/works', verifyToken, async (req, res) => {
    try {
        const { title, category, icon, short_desc, full_desc, image_url, sort_order } = req.body;
        const [result] = await pool.execute(
            'INSERT INTO works (title, category, icon, short_desc, full_desc, image_url, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [title, category, icon || 'fas fa-star', short_desc || '', full_desc || '', image_url || null, sort_order || 0]
        );
        res.json({ success: true, id: result.insertId });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 更新作品（需要登录）
app.put('/api/works/:id', verifyToken, async (req, res) => {
    try {
        const { title, category, icon, short_desc, full_desc, image_url, sort_order } = req.body;
        await pool.execute(
            'UPDATE works SET title=?, category=?, icon=?, short_desc=?, full_desc=?, image_url=?, sort_order=? WHERE id=?',
            [title, category, icon, short_desc, full_desc, image_url, sort_order, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 删除作品（需要登录）
app.delete('/api/works/:id', verifyToken, async (req, res) => {
    try {
        await pool.execute('DELETE FROM works WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 轮播图管理 ==========

// 获取轮播图列表（公开）
app.get('/api/carousel', async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT id, title, image_url, link_url, sort_order, is_active FROM carousel_images WHERE is_active = TRUE ORDER BY sort_order ASC, id DESC'
        );
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 获取所有轮播图（管理后台）
app.get('/api/carousel/all', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT id, title, image_url, link_url, sort_order, is_active FROM carousel_images ORDER BY sort_order ASC, id DESC'
        );
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 添加轮播图（需要登录）
app.post('/api/carousel', verifyToken, async (req, res) => {
    try {
        const { title, image_url, link_url, sort_order, is_active } = req.body;
        if (!image_url) {
            return res.status(400).json({ success: false, error: '请上传图片' });
        }
        const [result] = await pool.execute(
            'INSERT INTO carousel_images (title, image_url, link_url, sort_order, is_active) VALUES (?, ?, ?, ?, ?)',
            [title || '', image_url, link_url || '', sort_order || 0, is_active !== false]
        );
        res.json({ success: true, id: result.insertId });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 更新轮播图（需要登录）
app.put('/api/carousel/:id', verifyToken, async (req, res) => {
    try {
        const { title, image_url, link_url, sort_order, is_active } = req.body;
        await pool.execute(
            'UPDATE carousel_images SET title=?, image_url=?, link_url=?, sort_order=?, is_active=? WHERE id=?',
            [title || '', image_url, link_url || '', sort_order || 0, is_active !== false, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 删除轮播图（需要登录）
app.delete('/api/carousel/:id', verifyToken, async (req, res) => {
    try {
        await pool.execute('DELETE FROM carousel_images WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 网站设置 ==========

// 获取网站设置（公开）
app.get('/api/site-settings', async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT setting_key, setting_value, description FROM site_settings');
        const settings = {};
        rows.forEach(row => {
            settings[row.setting_key] = { value: row.setting_value, description: row.description };
        });
        res.json({ success: true, data: settings });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 更新网站设置（需要登录）
app.put('/api/site-settings', verifyToken, async (req, res) => {
    try {
        const { site_title, page_title, logo_icon } = req.body;
        if (site_title !== undefined) {
            await pool.execute('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', [site_title, 'site_title']);
        }
        if (page_title !== undefined) {
            await pool.execute('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', [page_title, 'page_title']);
        }
        if (logo_icon !== undefined) {
            await pool.execute('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', [logo_icon, 'logo_icon']);
        }
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 用户管理 ==========

// 获取所有用户（需要登录）
app.get('/api/users', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT id, username, created_at FROM admins ORDER BY id');
        const [settingRows] = await pool.execute("SELECT * FROM site_settings WHERE setting_key = 'disabled_users'");
        const disabledUsers = settingRows.length > 0 && settingRows[0].setting_value 
            ? JSON.parse(settingRows[0].setting_value) 
            : [];
        
        const users = rows.map(user => ({
            ...user,
            isDisabled: disabledUsers.includes(user.id)
        }));
        
        res.json({ success: true, data: users });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 修改用户密码（需要登录）
app.put('/api/users/:id/password', verifyToken, async (req, res) => {
    try {
        const { newPassword } = req.body;
        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ success: false, error: '密码至少6位' });
        }
        const hash = await bcrypt.hash(newPassword, 10);
        await pool.execute('UPDATE admins SET password_hash = ? WHERE id = ?', [hash, req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 禁用/启用用户（需要登录）
app.put('/api/users/:id/status', verifyToken, async (req, res) => {
    try {
        const { isDisabled } = req.body;
        const [settingRows] = await pool.execute("SELECT * FROM site_settings WHERE setting_key = 'disabled_users'");
        
        let disabledUsers = [];
        if (settingRows.length > 0 && settingRows[0].setting_value) {
            disabledUsers = JSON.parse(settingRows[0].setting_value);
        }
        
        if (isDisabled) {
            if (!disabledUsers.includes(parseInt(req.params.id))) {
                disabledUsers.push(parseInt(req.params.id));
            }
        } else {
            disabledUsers = disabledUsers.filter(id => id !== parseInt(req.params.id));
        }
        
        if (settingRows.length > 0) {
            await pool.execute('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', 
                [JSON.stringify(disabledUsers), 'disabled_users']);
        } else {
            await pool.execute('INSERT INTO site_settings (setting_key, setting_value, description) VALUES (?, ?, ?)',
                ['disabled_users', JSON.stringify(disabledUsers), '禁用用户ID列表']);
        }
        
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 删除用户（需要登录）
app.delete('/api/users/:id', verifyToken, async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        const [userRows] = await pool.execute('SELECT username FROM admins WHERE id = ?', [userId]);
        if (userRows.length === 0) {
            return res.status(404).json({ success: false, error: '用户不存在' });
        }
        if (userRows[0].username === 'admin') {
            return res.status(400).json({ success: false, error: '不能删除默认管理员' });
        }
        await pool.execute('DELETE FROM admins WHERE id = ?', [userId]);
        
        const [settingRows] = await pool.execute("SELECT * FROM site_settings WHERE setting_key = 'disabled_users'");
        if (settingRows.length > 0 && settingRows[0].setting_value) {
            let disabledUsers = JSON.parse(settingRows[0].setting_value);
            disabledUsers = disabledUsers.filter(id => id !== userId);
            await pool.execute('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?',
                [JSON.stringify(disabledUsers), 'disabled_users']);
        }
        
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 管理员作品审核 ==========

// 获取所有普通用户（需要登录）
app.get('/api/admin/users', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT id, username, avatar_url, email, created_at FROM users ORDER BY id');
        const [settingRows] = await pool.execute("SELECT * FROM site_settings WHERE setting_key = 'disabled_users'");
        const disabledUsers = settingRows.length > 0 && settingRows[0].setting_value
            ? JSON.parse(settingRows[0].setting_value)
            : [];

        const users = rows.map(user => ({
            ...user,
            isDisabled: disabledUsers.includes(user.id)
        }));

        res.json({ success: true, data: users });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 禁用/启用普通用户（需要登录）
app.put('/api/admin/users/:id/status', verifyToken, async (req, res) => {
    try {
        const { isDisabled } = req.body;
        const userId = parseInt(req.params.id);

        const [settingRows] = await pool.execute("SELECT * FROM site_settings WHERE setting_key = 'disabled_users'");

        let disabledUsers = [];
        if (settingRows.length > 0 && settingRows[0].setting_value) {
            disabledUsers = JSON.parse(settingRows[0].setting_value);
        }

        if (isDisabled) {
            if (!disabledUsers.includes(userId)) {
                disabledUsers.push(userId);
            }
        } else {
            disabledUsers = disabledUsers.filter(id => id !== userId);
        }

        if (settingRows.length > 0) {
            await pool.execute('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?',
                [JSON.stringify(disabledUsers), 'disabled_users']);
        } else {
            await pool.execute('INSERT INTO site_settings (setting_key, setting_value, description) VALUES (?, ?, ?)',
                ['disabled_users', JSON.stringify(disabledUsers), '禁用用户ID列表']);
        }

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 删除普通用户（需要登录）
app.delete('/api/admin/users/:id', verifyToken, async (req, res) => {
    try {
        const userId = parseInt(req.params.id);
        await pool.execute('DELETE FROM users WHERE id = ?', [userId]);
        await pool.execute('DELETE FROM works WHERE user_id = ?', [userId]);

        const [settingRows] = await pool.execute("SELECT * FROM site_settings WHERE setting_key = 'disabled_users'");
        if (settingRows.length > 0 && settingRows[0].setting_value) {
            let disabledUsers = JSON.parse(settingRows[0].setting_value);
            disabledUsers = disabledUsers.filter(id => id !== userId);
            await pool.execute('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?',
                [JSON.stringify(disabledUsers), 'disabled_users']);
        }

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 获取待审核作品（需要登录）
app.get('/api/admin/pending-works', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.execute(`
            SELECT w.*, u.username as submitter_name
            FROM works w
            LEFT JOIN users u ON w.user_id = u.id
            WHERE w.status = 'pending'
            ORDER BY w.submitted_at DESC
        `);
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 获取所有用户提交的作品（需要登录）
app.get('/api/admin/user-works', verifyToken, async (req, res) => {
    try {
        const { status, userId } = req.query;
        let query = `
            SELECT w.*, u.username as submitter_name
            FROM works w
            LEFT JOIN users u ON w.user_id = u.id
            WHERE w.user_id IS NOT NULL
        `;
        const params = [];

        if (status) {
            query += ' AND w.status = ?';
            params.push(status);
        }

        if (userId) {
            query += ' AND w.user_id = ?';
            params.push(userId);
        }

        query += ' ORDER BY w.submitted_at DESC';

        const [rows] = await pool.execute(query, params);
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 审核通过作品（需要登录）
app.put('/api/admin/works/:id/approve', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        await pool.execute(
            "UPDATE works SET status = 'approved' WHERE id = ?",
            [id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 审核拒绝作品（需要登录）
app.put('/api/admin/works/:id/reject', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;

        await pool.execute(
            "UPDATE works SET status = 'rejected', reject_reason = ? WHERE id = ?",
            [reason || '', id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 注册（需要注册码）==========
app.post('/api/register', async (req, res) => {
    try {
        const { username, password, registerCode } = req.body;

        // 验证输入
        if (!username || !password || !registerCode) {
            return res.status(400).json({ success: false, error: '请填写完整信息' });
        }

        if (username.length < 3) {
            return res.status(400).json({ success: false, error: '用户名至少3个字符' });
        }

        if (password.length < 6) {
            return res.status(400).json({ success: false, error: '密码至少6个字符' });
        }

        // 验证注册码
        const [codeRows] = await pool.execute(
            'SELECT * FROM register_codes WHERE code = ? AND is_used = FALSE',
            [registerCode]
        );

        if (codeRows.length === 0) {
            return res.status(400).json({ success: false, error: '注册码无效或已使用' });
        }

        const codeType = codeRows[0].code_type || 'admin';
        const targetTable = codeType === 'admin' ? 'admins' : 'users';

        // 检查用户名是否已存在（根据类型检查对应表）
        const [existing] = await pool.execute(`SELECT * FROM ${targetTable} WHERE username = ?`, [username]);
        if (existing.length > 0) {
            return res.status(400).json({ success: false, error: '用户名已存在' });
        }

        // 哈希密码并创建用户
        const hash = await bcrypt.hash(password, 10);
        await pool.execute(
            `INSERT INTO ${targetTable} (username, password_hash) VALUES (?, ?)`,
            [username, hash]
        );

        // 标记注册码已使用
        await pool.execute(
            'UPDATE register_codes SET is_used = TRUE, used_by = ?, used_at = NOW() WHERE code = ?',
            [username, registerCode]
        );

        // 生成token
        const token = jwt.sign(
            { id: username, username, type: codeType },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({ success: true, token, username, userType: codeType });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 用户登录 ==========
app.post('/api/user/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ success: false, error: '请填写用户名和密码' });
        }

        // 查找用户
        const [rows] = await pool.execute('SELECT * FROM users WHERE username = ?', [username]);
        if (rows.length === 0) {
            return res.status(401).json({ success: false, error: '用户名或密码错误' });
        }

        // 检查是否被禁用
        const [disabledRows] = await pool.execute("SELECT * FROM site_settings WHERE setting_key = 'disabled_users'");
        if (disabledRows.length > 0 && disabledRows[0].setting_value) {
            const disabledUsers = JSON.parse(disabledRows[0].setting_value);
            if (disabledUsers.includes(rows[0].id)) {
                return res.status(403).json({ success: false, error: '该账号已被禁用' });
            }
        }

        const valid = await bcrypt.compare(password, rows[0].password_hash);
        if (!valid) {
            return res.status(401).json({ success: false, error: '用户名或密码错误' });
        }

        const token = jwt.sign(
            { id: rows[0].id, username: rows[0].username, type: 'user' },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({ success: true, token, username: rows[0].username, userId: rows[0].id });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 用户注册 ==========
app.post('/api/user/register', async (req, res) => {
    try {
        const { username, password, registerCode } = req.body;

        if (!username || !password || !registerCode) {
            return res.status(400).json({ success: false, error: '请填写完整信息' });
        }

        if (username.length < 3) {
            return res.status(400).json({ success: false, error: '用户名至少3个字符' });
        }

        if (password.length < 6) {
            return res.status(400).json({ success: false, error: '密码至少6个字符' });
        }

        // 验证注册码（必须是user类型）
        const [codeRows] = await pool.execute(
            "SELECT * FROM register_codes WHERE code = ? AND is_used = FALSE AND (code_type = 'user' OR code_type IS NULL)",
            [registerCode]
        );

        if (codeRows.length === 0) {
            return res.status(400).json({ success: false, error: '注册码无效或已使用' });
        }

        // 检查用户名是否已存在
        const [existing] = await pool.execute('SELECT * FROM users WHERE username = ?', [username]);
        if (existing.length > 0) {
            return res.status(400).json({ success: false, error: '用户名已存在' });
        }

        // 哈希密码并创建用户
        const hash = await bcrypt.hash(password, 10);
        const [result] = await pool.execute(
            'INSERT INTO users (username, password_hash) VALUES (?, ?)',
            [username, hash]
        );

        // 标记注册码已使用
        await pool.execute(
            'UPDATE register_codes SET is_used = TRUE, used_by = ?, used_at = NOW() WHERE code = ?',
            [username, registerCode]
        );

        const token = jwt.sign(
            { id: result.insertId, username, type: 'user' },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({ success: true, token, username, userId: result.insertId });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 用户 Token 验证 ==========
app.get('/api/user/verify', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        res.json({ success: true, username: decoded.username, userId: decoded.id });
    } catch (err) {
        res.status(401).json({ success: false, error: 'token无效' });
    }
});

// ========== 用户资料管理 ==========
app.get('/api/user/profile', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        const [rows] = await pool.execute(
            'SELECT id, username, avatar_url, email, created_at FROM users WHERE id = ?',
            [decoded.id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ success: false, error: '用户不存在' });
        }

        res.json({ success: true, data: rows[0] });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.put('/api/user/profile', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        const { avatar_url, email } = req.body;
        await pool.execute(
            'UPDATE users SET avatar_url = ?, email = ? WHERE id = ?',
            [avatar_url || null, email || null, decoded.id]
        );

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.put('/api/user/password', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        const { oldPassword, newPassword } = req.body;
        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ success: false, error: '新密码至少6位' });
        }

        const [rows] = await pool.execute('SELECT password_hash FROM users WHERE id = ?', [decoded.id]);
        const valid = await bcrypt.compare(oldPassword, rows[0].password_hash);
        if (!valid) {
            return res.status(400).json({ success: false, error: '原密码错误' });
        }

        const hash = await bcrypt.hash(newPassword, 10);
        await pool.execute('UPDATE users SET password_hash = ? WHERE id = ?', [hash, decoded.id]);

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 用户作品管理 ==========
app.get('/api/user/works', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        const { status } = req.query;
        let query = 'SELECT * FROM works WHERE user_id = ?';
        const params = [decoded.id];

        if (status) {
            query += ' AND status = ?';
            params.push(status);
        }

        query += ' ORDER BY submitted_at DESC';

        const [rows] = await pool.execute(query, params);
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/user/works', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        const { title, category, icon, short_desc, full_desc, image_url } = req.body;

        if (!title || !category || !image_url) {
            return res.status(400).json({ success: false, error: '请填写完整信息' });
        }

        await pool.execute(
            `INSERT INTO works (title, category, icon, short_desc, full_desc, image_url, user_id, status, submitted_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())`,
            [title, category, icon || 'fas fa-star', short_desc || '', full_desc || '', image_url, decoded.id]
        );

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.put('/api/user/works/:id', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        const { id } = req.params;
        const { title, category, icon, short_desc, full_desc, image_url } = req.body;

        // 验证作品属于该用户
        const [rows] = await pool.execute(
            'SELECT * FROM works WHERE id = ? AND user_id = ?',
            [id, decoded.id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ success: false, error: '作品不存在或无权修改' });
        }

        // 如果作品已通过审核，修改后重新提交审核
        const status = rows[0].status === 'approved' ? 'pending' : rows[0].status;

        await pool.execute(
            `UPDATE works SET title = ?, category = ?, icon = ?, short_desc = ?, full_desc = ?, image_url = ?, status = ?
             WHERE id = ?`,
            [title, category, icon || 'fas fa-star', short_desc || '', full_desc || '', image_url, status, id]
        );

        res.json({ success: true, message: status === 'pending' ? '作品已重新提交审核' : '修改成功' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.delete('/api/user/works/:id', async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) {
            return res.status(401).json({ success: false, error: '未登录' });
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.type !== 'user') {
            return res.status(401).json({ success: false, error: '无效的token' });
        }

        const { id } = req.params;

        const [rows] = await pool.execute(
            'SELECT * FROM works WHERE id = ? AND user_id = ?',
            [id, decoded.id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ success: false, error: '作品不存在或无权删除' });
        }

        await pool.execute('DELETE FROM works WHERE id = ?', [id]);

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 管理员登录
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // 先检查是否是管理员
        const [adminRows] = await pool.execute('SELECT * FROM admins WHERE username = ?', [username]);
        if (adminRows.length > 0) {
            const valid = await bcrypt.compare(password, adminRows[0].password_hash);
            if (valid) {
                const token = jwt.sign({ id: adminRows[0].id, username, type: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
                return res.json({ success: true, token, username, userType: 'admin' });
            }
        }

        // 检查是否是普通用户
        const [userRows] = await pool.execute('SELECT * FROM users WHERE username = ?', [username]);
        if (userRows.length > 0) {
            const valid = await bcrypt.compare(password, userRows[0].password_hash);
            if (valid) {
                const token = jwt.sign({ id: userRows[0].id, username, type: 'user' }, JWT_SECRET, { expiresIn: '7d' });
                return res.json({ success: true, token, username, userType: 'user' });
            }
        }

        return res.status(401).json({ success: false, error: '用户名或密码错误' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 验证Token（前端用来检查登录状态）
app.get('/api/verify', verifyToken, (req, res) => {
    res.json({ success: true, user: req.user });
});

// ========== 注册码相关 API ==========
// 生成注册码（需要登录）
app.post('/api/register-codes/generate', verifyToken, async (req, res) => {
    try {
        const { count = 1, codeType = 'user' } = req.body;
        const codes = [];
        const prefix = codeType === 'admin' ? 'ADM-' : 'USR-';

        for (let i = 0; i < count; i++) {
            const code = prefix + Math.random().toString(36).substring(2, 10).toUpperCase();
            await pool.execute(
                'INSERT INTO register_codes (code, code_type) VALUES (?, ?)',
                [code, codeType]
            );
            codes.push(code);
        }

        res.json({ success: true, codes });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 获取所有注册码（需要登录）
app.get('/api/register-codes', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT * FROM register_codes ORDER BY created_at DESC'
        );
        res.json({ success: true, data: rows });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 使用注册码注册（公开）
app.post('/api/register', async (req, res) => {
    try {
        const { username, password, registerCode } = req.body;

        if (!username || username.length < 3) {
            return res.status(400).json({ success: false, error: '用户名至少需要3位' });
        }

        if (!password || password.length < 6) {
            return res.status(400).json({ success: false, error: '密码至少需要6位' });
        }

        if (!registerCode) {
            return res.status(400).json({ success: false, error: '请提供注册码' });
        }

        // 检查注册码是否有效
        const [codeRows] = await pool.execute(
            'SELECT * FROM register_codes WHERE code = ?',
            [registerCode]
        );

        if (codeRows.length === 0) {
            return res.status(400).json({ success: false, error: '注册码不存在' });
        }

        if (codeRows[0].is_used) {
            return res.status(400).json({ success: false, error: '注册码已被使用' });
        }

        // 检查用户名是否已存在
        const [userRows] = await pool.execute(
            'SELECT * FROM admins WHERE username = ?',
            [username]
        );

        if (userRows.length > 0) {
            return res.status(400).json({ success: false, error: '用户名已存在' });
        }

        // 创建新用户
        const hash = await bcrypt.hash(password, 10);
        const [result] = await pool.execute(
            'INSERT INTO admins (username, password_hash) VALUES (?, ?)',
            [username, hash]
        );

        // 标记注册码为已使用
        await pool.execute(
            'UPDATE register_codes SET is_used = TRUE, used_at = CURRENT_TIMESTAMP WHERE code = ?',
            [registerCode]
        );

        // 生成 token
        const token = jwt.sign({ id: result.insertId, username, type: 'admin' }, JWT_SECRET, { expiresIn: '7d' });
        res.json({ success: true, token, username, userType: 'admin' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// ========== 启动服务器 ==========
initDatabase().then(() => {
    app.listen(PORT, () => {
        console.log(`
╔══════════════════════════════════════════════════════════╗
║   🚀 服务器启动成功！                                     
║   📡 地址: http://localhost:${PORT}                      
║   🔐 默认管理员: admin / admin123                        
║   🔑 默认注册码: PORTFOLIO2025                           
║   📁 图片上传目录: public/uploads/                       
║                                                         
║   💡 注册流程:                                           
║      1. 点击「注册新账号」                                
║      2. 输入用户名、密码、注册码: PORTFOLIO2025            
║      3. 注册成功后自动登录                                
╚══════════════════════════════════════════════════════════╝
        `);
    });
});